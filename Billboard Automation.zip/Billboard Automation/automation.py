
import sys, time, os, getopt, threading
#used for the timer function

#used for multithreading and running functions at the same time
from datetime import date

#index of the photos
index = 0

sys.path.append('Libraries')

from Billboard import Billboard

parent_dir = str(os.getcwd()) + "\Camera Captures"
directory = str(date.today())
path = os.path.join(parent_dir, directory) 


kenJohBillboards = []
americanBillboards = []
MileHighBillboards = []
POAWBillboards = []
POAOBillboards = []
boards = []

def kenjoh():
    savedIndex = index
    if len(boards) > 0:
        for board in boards:
            for x in kenJohBillboards:
                if(board == x.name):
                    x.updateResponse()
                    x.writeImage(savedIndex, path + "/Kenjoh")
    else:
        for x in kenJohBillboards:
            x.updateResponse()
            x.writeImage(savedIndex, path + "/Kenjoh")

def American():
    savedIndex = index
    if len(boards) > 0:
        for board in boards:
            for x in americanBillboards:
                if(board == x.name):
                    x.updateResponse()
                    x.writeImage(savedIndex, path + "/American")
    else:
        for x in americanBillboards:
            x.updateResponse()
            x.writeImage(savedIndex, path + "/American")

def MileHigh():

    savedIndex = index
    if len(boards) > 0:
        for board in boards:
            for x in MileHighBillboards:
                if(board == x.name):
                    print(board)
                    x.updateResponse()
                    x.writeImage(savedIndex, path + "/Mile-High")
    else:
        for x in MileHighBillboards:
            x.updateResponse()
            x.writeImage(savedIndex, path + "/Mile-High")

#POAW seattle boards
def POAWMass():

    #save current image index
    savedIndex = index
    if len(boards) > 0:
        for board in boards:
            for x in POAWBillboards:
                if(board == x.name):
                    x.updateResponse()
                    x.writeImage(savedIndex, path + "/POAW")
    else:
        for x in POAWBillboards:
            x.updateResponse()
            x.writeImage(savedIndex, path + "/POAW")

#function for POAO
def POAOMass():
    savedIndex = index
    if len(boards) > 0:
        for board in boards:
            for x in POAOBillboards:
                if(board == x.name):
                    x.updateResponse()
                    x.writeImage(savedIndex, path + "/POAO")
    else:
        for x in POAOBillboards:
            x.updateResponse()
            x.writeImage(savedIndex, path + "/POAO")

def readBillboardFiles():

    kenJohBillboardsFile = open(str(os.getcwd() + "/Billboards/kenjoh.txt"), 'r')
    Lines = kenJohBillboardsFile.readlines()

    for line in Lines:
        split = line.split(",")
        kenJohBillboards.append(Billboard(split[0], split[1], split[2], split[3]))

    americanBillboardsFile = open(str(os.getcwd() + "/Billboards/american.txt"), 'r')
    Lines = americanBillboardsFile.readlines()

    for line in Lines:
        split = line.split(',')
        americanBillboards.append(Billboard(split[0], split[1], split[2], split[3]))

    MileHighBillboardsFile = open(str(os.getcwd() + "/Billboards/mile-high.txt"), 'r')
    Lines = MileHighBillboardsFile.readlines()

    for line in Lines:
        split = line.split(',')
        MileHighBillboards.append(Billboard(split[0], split[1], split[2], split[3]))

    POAWBillboardsFile = open(str(os.getcwd() + "/Billboards/pacific-seattle.txt"), 'r')
    Lines = POAWBillboardsFile.readlines()

    for line in Lines:
        split = line.split(',')
        POAWBillboards.append(Billboard(split[0], split[1], split[2], split[3]))

    POAOBillboardsFile = open(str(os.getcwd() + "/Billboards/pacific-washington.txt"), 'r')
    Lines = POAOBillboardsFile.readlines()

    for line in Lines:
        split = line.split(',')
        POAOBillboards.append(Billboard(split[0], split[1], split[2], split[3]))

#Main function, not needed but here for organization reasons
def createFolderStructure():
    os.mkdir(path)
    os.mkdir(path + "/American")
    os.mkdir(path + "/Kenjoh")
    os.mkdir(path + "/Mile-High")
    os.mkdir(path + "/POAO")
    os.mkdir(path + "/POAW")

    for i in kenJohBillboards:
        os.mkdir(path + "/Kenjoh/" + i.name)

    for i in americanBillboards:
        os.mkdir(path + "/American/" + i.name)

    for i in MileHighBillboards:
        os.mkdir(path + "/Mile-High/" + i.name)
    
    for i in POAOBillboards:
        os.mkdir(path + "/POAO/" + i.name)

    for i in POAWBillboards:
        os.mkdir(path + "/POAW/" + i.name)

def runCapture(timeLimit):
    #index of the photos
    index = 0
    keepRunning = True
    secondsTwo = 0
    seconds = 0
    minutes = 0
    #set the start time for the overall time
    time_start = time.time()

    #set the start time for the 8 second counter
    time_startTwo = time.time()
    while(keepRunning):

        #set the seconds to the amount of seconds passed 
        seconds = int(time.time() - time_start) - minutes * 60

        #seconds passed but not keeping track of minutes
        secondsTwo = int(time.time() - time_startTwo) - 0 * 60
        
        #timer for overall program, this is how long the program will run
        if(minutes >= timeLimit):
            keepRunning = False
        else:
            #this is to keep track of minutes, if seconds is over 60 
            if seconds >= 60:
                #add one to minutes and set seconds to 0
                minutes += 1
                seconds = 0
            #this is for the 8 second counter
            if(secondsTwo >= 4):
                #set the 8 second timer to 0
                secondsTwo = 0

                #set the new overall time to the current time
                time_startTwo = time.time()

                #create a thread for the POAO function
                POAOMassThread = threading.Thread(target=POAOMass)

                POAWMassThread = threading.Thread(target=POAWMass)

                MileHighThread = threading.Thread(target=MileHigh)

                AmericanThread = threading.Thread(target=American)

                kenjohThread = threading.Thread(target=kenjoh)
                #start the thread
                POAOMassThread.start()
                POAWMassThread.start()
                MileHighThread.start()
                AmericanThread.start()
                kenjohThread.start()

                #add one to the image index
                index += 1

def main(argv):
    timeLimit = 30
    
    try:
      opts, args = getopt.getopt(argv,"ht:b:",["time=","board="])
    except getopt.GetoptError:
      print('test.py -t <time limit> -b <billboard/s>')
      sys.exit(2)
    for opt, arg in opts:
      if opt == '-h':
         print('test.py -t <time limit> -b <billboard/s>')
         sys.exit()
      elif opt in ("-b", "--board"):
         boards = arg.split(" ")
      elif opt in ("-t", "--time"):
         timeLimit = int(arg)
    runCapture(timeLimit)
if __name__=='__main__':
    #kenjoh kenjo2020
    #kenjoh camera.812
    #main program loop
    readBillboardFiles()
    createFolderStructure()
    main(sys.argv[1:])