import requests
class Billboard:

    def __init__(self, name, url, username, password):
        self.url = url
        self.username = username
        self.password = password
        self.name = name
        self.response = None
        self.writeable = False
        
    def updateResponse(self):
        try:
            if(self.username is None and self.password is None):
                self.response = requests.get(self.url)
                self.writeable = True
            else:
                self.response = requests.get(self.url, auth=(self.username, self.password))
                self.writeable = True
        except:
            print("Unable to get " + self.name + " image")
            self.writeable = False

    def writeImage(self, imageIndex, path):
        if(self.response != None):
            if(len(self.response.content) > 500):
                try:
                    file = open(path + "/" + str(self.name) + "/" + self.name + "_" + str(imageIndex) + ".jpg", "wb")
                    file.write(self.response.content)
                    file.close()
                except:
                    print("Unable to write " + self.name + " image")
        
      
