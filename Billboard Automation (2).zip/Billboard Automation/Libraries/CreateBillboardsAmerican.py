from Billboard import Billboard

kenJohBillboardsFile = open(str(os.getcwd() + "/Billboards/kenjoh.txt"), 'r')
Lines = kenJohBillboardsFile.readlines()

for line in Lines:
    split = line.split(",")
    kenJohBillboards.append(Billboard(split[0], split[1], split[2], split[3]))
    print(split[0], split[1], split[2], split[3])
